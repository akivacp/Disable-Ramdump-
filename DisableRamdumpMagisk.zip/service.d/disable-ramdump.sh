#!/system/bin/sh
setprop persist.vendor.ramdump.enable 0
chmod 000 /data/vendor/ramdump
chattr +i /data/vendor/ramdump
