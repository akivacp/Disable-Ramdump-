#!/system/bin/sh
mkdir -p /data/adb/service.d
cp -f /system/bin/disable-ramdump.sh /data/adb/service.d/disable-ramdump.sh
chmod 755 /data/adb/service.d/disable-ramdump.sh
